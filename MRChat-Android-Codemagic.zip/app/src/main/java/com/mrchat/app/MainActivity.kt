package com.mrchat.app
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val p = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
  if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
  val missing = p.filter { ContextCompat.checkSelfPermission(this,it) != PackageManager.PERMISSION_GRANTED }
  if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
  val w=WebView(this)
  w.settings.javaScriptEnabled=true
  w.settings.domStorageEnabled=true
  w.settings.mediaPlaybackRequiresUserGesture=false
  w.webViewClient=WebViewClient()
  w.webChromeClient=WebChromeClient()
  w.loadUrl("https://mrchat.ct.ws/")
  setContentView(w)
 }
}
