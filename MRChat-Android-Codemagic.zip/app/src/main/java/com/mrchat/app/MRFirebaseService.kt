package com.mrchat.app
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MRFirebaseService: FirebaseMessagingService() {
 override fun onMessageReceived(m: RemoteMessage) {
  val nm=getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
  val id="incoming_calls"
  if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(NotificationChannel(id,"مكالمات M.R Chat",NotificationManager.IMPORTANCE_HIGH))
  nm.notify(9001, NotificationCompat.Builder(this,id)
   .setSmallIcon(android.R.drawable.sym_call_incoming)
   .setContentTitle(m.data["title"] ?: "مكالمة واردة")
   .setContentText(m.data["body"] ?: "لديك مكالمة واردة")
   .setCategory(NotificationCompat.CATEGORY_CALL)
   .setPriority(NotificationCompat.PRIORITY_MAX)
   .setAutoCancel(true).setVibrate(longArrayOf(0,500,300,500)).build())
 }
}
