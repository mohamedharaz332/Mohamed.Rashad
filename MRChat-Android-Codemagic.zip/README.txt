M.R Chat Android starter.
Website backend: https://mrchat.ct.ws/
For Firebase push notifications, create a Firebase Android app with package com.mrchat.app and add google-services.json at app/google-services.json.
Connect this repository to Codemagic and run android-debug.
